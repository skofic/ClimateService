#!/bin/sh

###
# Import DroughtObservatory original file in temporary collection.
###

###
# Load default parameters.
###
source "${HOME}/.GeoService"
file="/home/ArangoDB/backup/GeoService/DroughtObservatory_36be67f5e3299a69edc4e8d2a41a5633.data.json.gz"

echo ""
echo "==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>"
echo "==> ImportDroughtObservatory.sh"
echo "==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>"
echo ""
START=$(date +%s)

###
# Import dataset in tempfile.
##
arangoimport \
	--server.endpoint "$host" \
	--server.database "$base" \
	--server.username "$user" \
	--server.password "$pass" \
	--file "$file" \
	--type "jsonl" \
	--collection "temp" \
	--create-collection true \
	--create-collection-type "document" \
	--overwrite true \
	--progress true
if [ $? -ne 0 ]
then
	echo "*************"
	echo "*** ERROR ***"
	echo "*************"
	exit 1
fi

END=$(date +%s)
elapsed=$((END-START))
echo ""
echo "==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>"
echo "==> ImportDroughtObservatory.sh - TOTAL TIME: $elapsed seconds"
echo "==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>==>"
echo ""
