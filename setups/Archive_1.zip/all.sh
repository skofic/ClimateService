#!/bin/sh

###
# Do stuff.
# Remember to create temp collection.
###

###
# Load default parameters.
###
source "${HOME}/.GeoService"

cmd="${path}/setups/UnitShapes.export.sh"
sh $cmd
if [ $? -ne 0 ]
then
	echo "*************"
	echo "*** ERROR ***"
	echo "*************"
	exit 1
fi

cmd="${path}/setups/SpeciesOccurrences.export.sh"
sh $cmd
if [ $? -ne 0 ]
then
	echo "*************"
	echo "*** ERROR ***"
	echo "*************"
	exit 1
fi

echo "===> DONE!"
