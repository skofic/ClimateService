#!/bin/sh

###
# Do stuff.
# Remember to create temp collection.
###

###
# Load default parameters.
###
source "${HOME}/.GeoService"

cmd="${path}/setups/4.ImportDroughtObservatory.sh"
sh $cmd
if [ $? -ne 0 ]
then
	echo "*************"
	echo "*** ERROR ***"
	echo "*************"
	exit 1
fi

cmd="${path}/setups/DroughtObservatory.export.sh"
sh $cmd
if [ $? -ne 0 ]
then
	echo "*************"
	echo "*** ERROR ***"
	echo "*************"
	exit 1
fi

echo "===> DONE!"
